package com.appnexus.oas.demo;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.appnexus.oas.demo.util.Constant;
import com.appnexus.oas.mobilesdk.IAdClickListener;
import com.appnexus.oas.mobilesdk.IBannerAd;
import com.appnexus.oas.mobilesdk.IHandleClickToAction;
import com.appnexus.oas.mobilesdk.IReceiveAd;
import com.appnexus.oas.mobilesdk.XAdView;
import com.appnexus.oas.mobilesdk.configuration.XAdSlotConfiguration;
import com.appnexus.oas.mobilesdk.errorhandler.XAdException;
import com.appnexus.oas.mobilesdk.utilities.XConstant.ACTION_TYPE;
import com.appnexus.oas.mobilesdk.utilities.XLogUtil;

public class XBannerWithCallbackActivity extends Activity {
	private TextView logsTextView;
	private Handler handler;
	StringBuilder logStr = new StringBuilder();
	String sdkVersion;
	XAdSlotConfiguration adSlotConfiguration;
	private boolean isDialogVisible;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		handler = new Handler();
		registerAmazon();
		if (Constant.isStandardBannerAd) {
			displayStandardBanner();
		} else {
			displayRichMediaAd();
		}
		initializeTextView();
	}
	
	public void registerAmazon() {

		try {
			
			Class<?> adRegistration = Class
					.forName("com.amazon.device.ads.AdRegistration");
			Method method = adRegistration.getDeclaredMethod("setAppKey",String.class);
			method.invoke(null, "123");
		} catch (ClassNotFoundException ignored) {
		} catch (NoSuchMethodException ignored) {
		} catch (InvocationTargetException ignored) {
		} catch (IllegalAccessException ignored) {
		}

	}

	/**
	 * Displays a rich media banner (html based ads)
	 */
	@SuppressWarnings("deprecation")
	private void displayRichMediaAd() {
		setContentView(R.layout.activity_richmedia);
		XAdView xAdView = new XAdView(this, adListener);
		xAdView.setAdClickListener(adClickListener);
		xAdView.setAdClickToActionListener(clickActionListener);
		xAdView.setBannerAdEventsListener(bannerEventsListener);
		xAdView.getAdSlotConfiguration().setBannerRefreshInterval(120);
		xAdView.getAdSlotConfiguration().setOpenInExternalBrowser(true);
		
		xAdView.getAdSlotConfiguration().setMediationEnabled(true);
		xAdView.getAdSlotConfiguration().setMediationPlacementId("2126997");
        xAdView.getAdSlotConfiguration().setMediatedBannerSize(320, 50);

		RelativeLayout.LayoutParams layoutparams = new RelativeLayout.LayoutParams(
				getSizeInDP(this, 320), getSizeInDP(this, 50));
		layoutparams.addRule(RelativeLayout.ALIGN_PARENT_TOP);
		layoutparams.addRule(RelativeLayout.CENTER_HORIZONTAL);
		xAdView.setLayoutParams(layoutparams);
		((RelativeLayout) this.findViewById(R.id.ad_richmedia_id)).addView(xAdView);

		Drawable defaultBackground = getResources().getDrawable(R.drawable.noad);
		
		xAdView.getAdSlotConfiguration().setBackgroundImage(defaultBackground);
		xAdView.getAdSlotConfiguration().setOpenInExternalBrowser(false);

		xAdView.loadAd(Constant.DEFAULT_DOMAIN_MRAID,
				"MSDK-Celtra-MRAID2-ExpandableBanner-a15e2c7e", "x25", null,
				null);
	}

	/**
	 * Displays the standard banner (image based ads)
	 * 
	 */
	@SuppressWarnings("deprecation")
	private void displayStandardBanner() {
		setContentView(R.layout.activity_standardandrichbanner);
		XAdView xAdView = new XAdView(this, adListener);
		xAdView.setAdClickListener(adClickListener);
		xAdView.setAdClickToActionListener(clickActionListener);
		xAdView.getAdSlotConfiguration().setScalable(true);
		xAdView.getAdSlotConfiguration().setOpenInExternalBrowser(false);
		xAdView.getAdSlotConfiguration().setBannerRefreshInterval(120);
		Drawable defaultBackground = getResources()
				.getDrawable(R.drawable.noad);
		xAdView.getAdSlotConfiguration().setBackgroundImage(defaultBackground);

		RelativeLayout.LayoutParams layoutparams = new RelativeLayout.LayoutParams(
				getSizeInDP(this, 320), getSizeInDP(this, 50));
		layoutparams.addRule(RelativeLayout.ALIGN_PARENT_TOP);
		layoutparams.addRule(RelativeLayout.CENTER_HORIZONTAL);
		xAdView.setLayoutParams(layoutparams);

		((RelativeLayout) findViewById(R.id.standardandrichcontainer_id))
				.addView(xAdView);
		xAdView.loadAd(Constant.DEFAULT_DOMAIN_MRAID,
				"demo_standardbanner", "Bottom", null, null);

	}

	private void initializeTextView() {
		logsTextView = (TextView) this.findViewById(R.id.txtview);
		logsTextView.setSelected(true);
		logsTextView.setMovementMethod(new ScrollingMovementMethod());
		logsTextView.setVisibility(1);
	}

	/**
	 * Returns the value according to device's density pixels.
	 * 
	 * @param context
	 * @param pixelSize
	 * @return
	 */
	public int getSizeInDP(Context context, int pixelSize) {
		float scale = context.getResources().getDisplayMetrics().density;
		int sizeInDP = (int) (pixelSize * scale);
		return sizeInDP;
	}

	IReceiveAd adListener = new IReceiveAd() {

		@Override
		public void xAdLoaded(View xAdView) {
			logStr.append(String
					.format("\n\txAdLoaded()\n\tBanner ad loaded successfully \n"));
			logsTextView.setText(logStr);
		}

		@Override
		public boolean xAdShouldDisplay(View xAdView, WebView adWebView,
				String htmlContent) {
			boolean permission = true;
			logStr.append(String
					.format("\n\txAdShouldDisplay()\n\tShould display ad? --- "
							+ (permission == true ? "Yes" : "No"))
					+ "\n");
			logsTextView.setText(logStr);
			return permission;
		}

		@Override
		public void xAdFailed(View xAdView, XAdException xAdError) {
			logStr.append(String
					.format("\n\txAdFailed()\n\tAd failed to load \n"));
			logsTextView.setText(logStr);
		}
	};

	IBannerAd bannerEventsListener = new IBannerAd() {

		@Override
		public void onBannerAdExpand(XAdView arg0) {
			Log.d("XBanner", "onBannerAdExpand()\n"
					+ "Banner is Expanded");
			handler.post(new Runnable() {
				public void run() {
					logStr.append(String
							.format(" \n\tonBannerAdExpand()\n\tBanner is Expanded \n"));
					logsTextView.setText(logStr);
				}
			});
		}

		@Override
		public void onBannerClosed() {
			Log.d("XBanner", "onBannerClosed()\n"
					+ "Banner is Closed");
			handler.post(new Runnable() {
				public void run() {
					logStr.append(String
							.format("\n\tonBannerClosed()\n\tBanner is Closed \n"));
					logsTextView.setText(logStr);
				}
			});
		}

		@Override
		public void onBannerResize(int arg0, int arg1) {
			Log.d("XBanner", "onBannerResize()\n"
					+ "The ad resized");
			handler.post(new Runnable() {
				public void run() {
					logStr.append(String
							.format("\n\tonBannerResize()\n\tBanner is Resized \n"));
					logsTextView.setText(logStr);
				}
			});

		}
	};

	IAdClickListener adClickListener = new IAdClickListener() {

		@Override
		public void onBrowserOpen(XAdView xAdView) {
			handler.post(new Runnable() {
				public void run() {
					logStr.append(String.format("\n\tonBrowserOpen()\n\t Browser opened \n"));
					logsTextView.setText(logStr);
					Log.d("XBanner", "onBrowserOpen()\n");
				}
			});
		}

		@Override
		public void onBrowserClose(XAdView xAdView) {
			handler.post(new Runnable() {
				public void run() {
					logStr.append(String.format("\n\tonBrowserClose()\n\t Browser closed \n"));
					logsTextView.setText(logStr);
					Log.d("XBanner", "onBrowserClose()\n");
				}
			});
		}

		@Override
		public void onLeaveApplication(XAdView xAdView) {
			handler.post(new Runnable() {
				public void run() {
					logStr.append(String.format("\n\tonLeaveApplication()\n\t Application has left \n"));
					logsTextView.setText(logStr);
					Log.d("XBanner",
							"onLeaveApplication()\n");
				}
			});

		}

	};

	IHandleClickToAction clickActionListener = new IHandleClickToAction() {

		@Override
		public boolean shouldHandleClickToAction(ACTION_TYPE actionType,
				Intent actionIntent) {
			XLogUtil.d("XBannerWithCallbackActivity", "actionType "
					+ actionType);
			XLogUtil.d("XBannerWithCallbackActivity", "actionIntent "
					+ actionIntent);
			if (!isDialogVisible) {
				showActionDialog(actionIntent);
			}
			return true;
		}
	};

	private void showActionDialog(final Intent actionIntent) {
		AlertDialog.Builder actionDialog = new AlertDialog.Builder(
				XBannerWithCallbackActivity.this);
		// actionDialog.setTitle("Confirm Action");
		actionDialog.setCancelable(false);
		actionDialog.setMessage("Do you want to continue?");
		actionDialog.setPositiveButton("YES",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						isDialogVisible = false;
						startActivity(actionIntent);
					}
				});
		actionDialog.setNegativeButton("NO",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						isDialogVisible = false;
						dialog.cancel();
					}
				});
		actionDialog.show();
		isDialogVisible = true;
	}
}
