package com.appnexus.oas.demo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import android.widget.TextView;

import com.appnexus.oas.demo.util.Constant;
import com.appnexus.oas.mobilesdk.IAdClickListener;
import com.appnexus.oas.mobilesdk.IHandleClickToAction;
import com.appnexus.oas.mobilesdk.IInterstitialAd;
import com.appnexus.oas.mobilesdk.IReceiveAd;
import com.appnexus.oas.mobilesdk.IVideoAd;
import com.appnexus.oas.mobilesdk.XAdView;
import com.appnexus.oas.mobilesdk.XInterstitialAdDialog;
import com.appnexus.oas.mobilesdk.errorhandler.XAdException;
import com.appnexus.oas.mobilesdk.utilities.XConstant.ACTION_TYPE;
import com.appnexus.oas.mobilesdk.utilities.XLogUtil;

public class XInterstitialWithCallbackActivity extends Activity {
	private TextView txtView;
	StringBuilder logStr = new StringBuilder();
	private boolean isDialogVisible;
	XInterstitialAdDialog dialog;
	private Handler handler;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_interstitial);
		txtView = (TextView) this.findViewById(R.id.txtview);
		txtView.setSelected(true);
		txtView.setMovementMethod(new ScrollingMovementMethod());
		txtView.setVisibility(1);
		handler = new Handler();
		if (Constant.isMraidInterstitial == true) {
			showXMraidView();
		} else {
			showVastView();
		}

	}

	/**
	 * show MRAID interstitial ad
	 */
	private void showXMraidView() {
		/*dialog = new XInterstitialAdDialog(this,
				Constant.DEFAULT_DOMAIN_MRAID,
				"MSDK-Joule-interstitial-TF1_Eurosport_iPhone_RM_int-249058",
				"x93", null, null);*/
		
		/**
		 * NEW FEATURE - DYNAMIC MEDIATION
		 * Below ad request fetches an XML based house ad which triggers the SDK to enable mediation dynamically.
		 * It takes precedence over the value of mediationEnable flag, placement id, width and height parameters from ad slot configuration.
		 */
		dialog = new XInterstitialAdDialog(this,
				Constant.DEFAULT_DOMAIN_MRAID_TF1,
				"mnews_banner.com",
				"Bottom3", null, null);

		dialog.getAdSlotConfiguration().setOpenInExternalBrowser(false);
		dialog.getAdSlotConfiguration().setMediationEnabled(false);
		dialog.getAdSlotConfiguration().setMediationPlacementId("2054679");
		dialog.setInterstitialAdListener(interstitialAdListener);
		dialog.setAdListener(adListener);
		dialog.setAdClickListener(adClickListener);
		dialog.setClickToActionListener(clickToActionListener);

		dialog.show();
	}

	/**
	 * shoe VAST interstitial ad
	 */
	private void showVastView() {
		dialog = new XInterstitialAdDialog(this,
				Constant.DEFAULT_DOMAIN_MRAID_TF1, "vast_preroll", "Bottom", null,
				null);
		dialog.getAdSlotConfiguration().setOpenInExternalBrowser(true);

		dialog.setAdListener(adListener);
		dialog.setAdClickListener(adClickListener);
		dialog.setVideoAdListener(videoAdListener);
		dialog.setInterstitialAdListener(interstitialAdListener);
		dialog.show();

	}

	IInterstitialAd interstitialAdListener = new IInterstitialAd() {

		@Override
		public void onInterstitialAdClose() {
			logStr.append(String
					.format("\n\tonInterstitialAdClose()\n\tInterstitial ad closed \n"));
			txtView.setText(logStr);
		}
	};

	IReceiveAd adListener = new IReceiveAd() {

		@Override
		public void xAdLoaded(View xAdView) {
			logStr.append(String
					.format("\n\txAdLoaded()\n\tInterstitial ad loaded successfully \n"));
			txtView.setText(logStr);
			Log.d("XInterstitialCB", "XInterstitialCB xAdLoaded()\n"
					+ "The ad was loaded successfully");
		}

		@Override
		public boolean xAdShouldDisplay(View xAdView, WebView adWebView,
				String htmlContent) {
			boolean permission = true;
			logStr.append(String
					.format("\n\txAdShouldDisplay()\n\tShould display ad? --- "
							+ (permission == true ? "Yes" : "No"))
					+ "\n");
			txtView.setText(logStr);
			Log.d("XInterstitialCB", "XInterstitialCB xAdShouldDisplay()\n"
					+ "HTML: " + htmlContent);
			return permission;
		}

		@Override
		public void xAdFailed(View xAdView, XAdException xAdError) {
			logStr.append(String
					.format("\n\txAdFailed()\n\tAd failed to load \n"));
			txtView.setText(logStr);
			Log.d("XInterstitialCB",
					"XInterstitialCB xAdFailed()\n" + xAdError.getMessage());
		}
	};

	IHandleClickToAction clickToActionListener = new IHandleClickToAction() {

		@Override
		public boolean shouldHandleClickToAction(ACTION_TYPE actionType,
				Intent actionIntent) {
			XLogUtil.d("XInterstitialCB ", "actionType " + actionType);
			XLogUtil.d("XInterstitialCB ", "actionIntent " + actionIntent);
			if (!isDialogVisible) {
				showActionDialog(actionIntent);
			}
			return true;
		}
	};

	IAdClickListener adClickListener = new IAdClickListener() {

		@Override
		public void onBrowserOpen(XAdView xAdView) {
			
			handler.post(new Runnable() {
				public void run() {
					logStr.append(String.format("\n\tonBrowserOpen()\n\t Browser opened \n"));
					txtView.setText(logStr);
					Log.d("XBanner", "onBrowserOpen()\n");
				}
			});
			
			Log.d("XInterstitialCB", "XInterstitialCB onBrowserOpen()\n");
		}

		@Override
		public void onBrowserClose(XAdView xAdView) {
			logStr.append(String.format("\n\t\t onBrowserClose()\n"
					+ "\t Browser closed \n"));
			txtView.setText(logStr);
			Log.d("XInterstitialCB", "XInterstitialCB onBrowserClosed()\n");
		}

		@Override
		public void onLeaveApplication(XAdView xAdView) {
			logStr.append(String.format("\n\t\t onLeaveApplication()\n"
					+ "\t\t Application has left \n"));
			txtView.setText(logStr);
			Log.d("XInterstitialCB", "XInterstitialCB onLeaveApplication()\n");
		}
	};

	IVideoAd videoAdListener = new IVideoAd() {

		@Override
		public void onVideoPlay() {
			logStr.append(String.format("\n\t\t onVideoPlay()\n"
					+ "\t\t Video ad start playing \n"));
			txtView.setText(logStr);
			Log.d("XInterstitialCB", " XInterstitialCB onVideoPlay()\n");
		}

		@Override
		public void onVideoPause(long duration) {
			logStr.append(String.format("\n\t\t onVideoPause()\n"
					+ "\t\tVideo ad paused \n"));
			txtView.setText(logStr);
			Log.d("XInterstitialCB", "XInterstitialCB onVideoPause()\n");
		}

		@Override
		public void onVideoResume(long duration) {
			logStr.append(String.format("\n\t\t onVideoResume()\n"
					+ "\t\tVideo ad resumed \n"));
			txtView.setText(logStr);
			Log.d("XInterstitialCB", "XInterstitialCB onVideoResume()\n");
		}

		@Override
		public void onVideoSkip(long duration) {
			logStr.append(String.format("\n\t\t onVideoSkip()\n"
					+ "\t\t Video ad skiped \n"));
			txtView.setText(logStr);
			Log.d("XInterstitialCB", "XInterstitialCB onVideoSkip()\n");
		}

		@Override
		public void onMuteVideo() {
			logStr.append(String.format("\n\t\t onMuteVideo()\n"
					+ "\t\t Video ad muted \n"));
			txtView.setText(logStr);
			Log.d("XInterstitialCB", "XInterstitialCB onMuteVideo()\n");
		}

		@Override
		public void onUnMuteVideo() {
			logStr.append(String.format("\n\t\t onUnMuteVideo()\n"
					+ "\t\t Video ad unmuted \n"));
			txtView.setText(logStr);
			Log.d("XInterstitialCB", "XInterstitialCB onUnMuteVideo()\n");
		}

		@Override
		public void onQuartileFinish(int xVideoQuartile) {
			logStr.append(String.format("\n\t\t onQuartileFinish()\n" + "\t\t"
					+ xVideoQuartile + " QuartileFinished \n"));
			txtView.setText(logStr);
			Log.d("XInterstitialCB", "XInterstitialCB onQuartileFinish()\n");
		}

		@Override
		public void onVideoPlayerEnterFullScreenMode() {
			logStr.append(String
					.format("\n\t\t onVideoPlayerEnterFullScreenMode()\n"
							+ "\t\t Video ad Entered Full ScreenMode \n"));
			txtView.setText(logStr);
			Log.d("XInterstitialCB",
					"XInterstitialCB onVideoPlayerEnterFullScreenMode()\n");
		}

		@Override
		public void onVideoPlayerExitFullScreenMode() {
			logStr.append(String
					.format("\n\t\t onVideoPlayerExitFullScreenMode()\n"
							+ "\t\t Video ad Exited Full ScreenMode \n"));
			txtView.setText(logStr);
			Log.d("XInterstitialCB",
					"XInterstitialCB onVideoPlayerExitFullScreenMode()\n");
		}

		@Override
		public void onVideoPlayerRewind(long fromduration, long toduration) {
			logStr.append(String.format("\n\t\t onVideoPlayerRewind()\n"
					+ "\t\t Video ad rewided \n"));
			txtView.setText(logStr);
			Log.d("XInterstitialCB", "XInterstitialCB onVideoPlayerRewind()\n");
		}

		@Override
		public void onVideoClick(MotionEvent event) {
			logStr.append(String.format("\n\t\t onVideoClick()\n"
					+ "\t\t On video clicked \n"));
			txtView.setText(logStr);
			Log.d("XInterstitialCB", "XInterstitialCB onVideoClick()\n");
		}

		public void onPrerollAdFinished() {
			logStr.append(String.format("\n\t\t The video ad Finished \n"));
			txtView.setText(logStr);
			Log.d("XInterstitialCB", "XInterstitialCB onPrerollAdFinished()\n");
		}

	};

	private void showActionDialog(final Intent actionIntent) {
		AlertDialog.Builder actionDialog = new AlertDialog.Builder(
				XInterstitialWithCallbackActivity.this);
		actionDialog.setCancelable(false);
		actionDialog.setMessage("Are you sure you want to continue?");
		actionDialog.setPositiveButton("YES",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						isDialogVisible = false;
						startActivity(actionIntent);
					}
				});
		actionDialog.setNegativeButton("NO",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						isDialogVisible = false;
						dialog.cancel();
					}
				});
		actionDialog.show();
		isDialogVisible = true;
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		
	}
}
