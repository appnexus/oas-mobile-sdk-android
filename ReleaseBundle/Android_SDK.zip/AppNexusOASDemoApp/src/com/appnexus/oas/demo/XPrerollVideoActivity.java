package com.appnexus.oas.demo;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.Toast;
import android.widget.VideoView;

import com.appnexus.oas.demo.util.Constant;
import com.appnexus.oas.mobilesdk.IAdClickListener;
import com.appnexus.oas.mobilesdk.IReceiveAd;
import com.appnexus.oas.mobilesdk.IVideoAd;
import com.appnexus.oas.mobilesdk.XAdView;
import com.appnexus.oas.mobilesdk.XVideoAdController;
import com.appnexus.oas.mobilesdk.configuration.XAdSlotConfiguration.LABEL_POSITION;
import com.appnexus.oas.mobilesdk.configuration.XAdSlotConfiguration.SKIP_OFFSET_TYPE;
import com.appnexus.oas.mobilesdk.errorhandler.XAdException;
import com.appnexus.oas.mobilesdk.requestenrichment.XDeviceInformation;
import com.appnexus.oas.mobilesdk.utilities.XLogUtil;

public class XPrerollVideoActivity extends Activity implements IVideoAd,
		IReceiveAd,IAdClickListener {

	private String mediaContentUrl = Constant.PRE_ROLL_VAST_VIDEO_URL;
	private Uri uri;
	private VideoView videoView;
	private Handler handler;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_vastvideo);
		handler = new Handler();
		videoView = (VideoView) findViewById(R.id.videoView);
		
		RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.baseLayout);
		XVideoAdController videoAds = new XVideoAdController(this, this, this);
		videoAds.getAdSlotConfiguration().setOpenInExternalBrowser(true);
		/*
		 * NEW FEATURE - Now countdown position can be configured to 6 different locations over the video. 
		 * Default location is top right corner of video.
		 */
		videoAds.getAdSlotConfiguration().setCountdownLabelPosition(LABEL_POSITION.TOP_CENTER);
		
		/*
		 * NEW FEATURE - Configurable Skip Offset
		 * Type and Value of skip offset can now be configured using following method
		 */
		videoAds.getAdSlotConfiguration().setSkipOffset(20, SKIP_OFFSET_TYPE.RELATIVE);
		
		/*
		 * NEW FEATURE - Video Dissmiss on click is now optional
		 * As a default behaviour SDK would pause the video ad on click and resume when user returns back to the screen.
		 * This can be configured via below method
		 */
		videoAds.getAdSlotConfiguration().setDismissVideoAdOnClick(false);
		
		videoAds.requestPrerollAd(getApplicationContext(), videoView,
				relativeLayout, Constant.DEFAULT_DOMAIN_MRAID_TF1, "vast_preroll", "Bottom", null, null);
		
	}

	@Override
	public void onVideoPlay() {
		Log.d("XPrerollVideoActivity", "XPrerollVideoActivity onVideoPlay()\n");
	}

	@Override
	public void onVideoPause(long duration) {
		Log.d("XPrerollVideoActivity", "XPrerollVideoActivity onVideoPause()\n");
	}

	@Override
	public void onVideoResume(long duration) {
		Log.d("XPrerollVideoActivity", "XPrerollVideoActivity onVideoResume()\n");
	}

	@Override
	public void onVideoSkip(long duration) {
		Log.d("XPrerollVideoActivity", "XPrerollVideoActivity onVideoSkip()\n");
	}

	@Override
	public void onMuteVideo() {
		Log.d("XPrerollVideoActivity", "XPrerollVideoActivity onMuteVideo()\n");
	}

	@Override
	public void onUnMuteVideo() {
		Log.d("XPrerollVideoActivity", "XPrerollVideoActivity onUnMuteVideo()\n");
	}

	@Override
	public void onQuartileFinish(int xVideoQuartile) {
		Log.d("XPrerollVideoActivity", "XPrerollVideoActivity onQuartileFinish()\n");
	}

	@Override
	public void onVideoPlayerEnterFullScreenMode() {
		Log.d("XPrerollVideoActivity", "XPrerollVideoActivity onVideoPlayerEnterFullScreenMode()\n");
		findViewById(R.id.baseLayout).getLayoutParams().width = LayoutParams.MATCH_PARENT;
		findViewById(R.id.baseLayout).getLayoutParams().height = LayoutParams.MATCH_PARENT;
	}

	@Override
	public void onVideoPlayerExitFullScreenMode() {
		Log.d("XPrerollVideoActivity", "XPrerollVideoActivity onVideoPlayerExitFullScreenMode()\n");
		
		// Resize VideoView's container
		findViewById(R.id.baseLayout).getLayoutParams().width = getSizeInDP(getApplicationContext(), 360);
		findViewById(R.id.baseLayout).getLayoutParams().height = getSizeInDP(getApplicationContext(), 330);
	}

	@Override
	public void onVideoPlayerRewind(long fromduration, long toduration) {
		Log.d("XPrerollVideoActivity", "XPrerollVideoActivity onVideoPlayerRewind()\n");
	}

	@Override
	public void onVideoClick(MotionEvent event) {
		Log.d("XPrerollVideoActivity", "XPrerollVideoActivity onVideoClick()\n");
	}

	public void onPrerollAdFinished() {
		XLogUtil.d("XPrerollVideoActivity",
				"XPrerollVideoActivity onPrerollAdFinished ");
		playContentVideo();
	}

	private void playContentVideo() {
		
		// Resize VideoView's container
		findViewById(R.id.baseLayout).getLayoutParams().width = getSizeInDP(getApplicationContext(), 360);
		findViewById(R.id.baseLayout).getLayoutParams().height = getSizeInDP(getApplicationContext(), 330);
		
		MediaController controller = new MediaController(this);
		controller.setAnchorView(videoView);
		controller.setMediaPlayer(videoView);
		videoView.setMediaController(controller);
		uri = Uri.parse(mediaContentUrl);
		videoView.setVideoURI(uri);
		videoView.requestFocus();
		videoView.start();
		
	}

	@Override
	public void xAdLoaded(View xAdView) {
	}

	@Override
	public boolean xAdShouldDisplay(View xAdView, WebView adWebView, String htmlContent) {
		return true;
	}
	
	@Override
	public void xAdFailed(View xAdView, final XAdException xAdError) {
		handler.post(new Runnable() {
			public void run() {
				Toast.makeText(getApplicationContext(), xAdError.getMessage(),
						Toast.LENGTH_LONG).show();
			}
		});
	}

	@Override
	public void onBrowserOpen(XAdView xAdView) {
		Log.d("XPrerollVideoActivity", "XPrerollVideoActivity onBrowserOpen()\n");		
	}

	@Override
	public void onBrowserClose(XAdView xAdView) {
		Log.d("XPrerollVideoActivity", "XPrerollVideoActivity onBrowserClose()\n");		
	}

	@Override
	public void onLeaveApplication(XAdView xAdView) {
		Log.d("XPrerollVideoActivity", "XPrerollVideoActivity onLeaveApplication()\n");
	}
	
	/**
	 * Returns the value according to device's density pixels.
	 * 
	 * @param context
	 * @param pixelSize
	 * @return
	 */
	public static int getSizeInDP(Context context, int pixelSize) {
		float scale = XDeviceInformation.getDensity(context);
		int sizeInDP = (int) (pixelSize * scale);
		return sizeInDP;
	}
	

}
