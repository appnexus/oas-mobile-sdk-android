package com.appnexus.oas.demo;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import com.appnexus.oas.mobilesdk.XAdView;

public class XStandardBannerActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_standardbanner);
		Drawable defaultBackground = getResources().getDrawable(R.drawable.noad);
		((XAdView)findViewById(R.id.xadview)).getAdSlotConfiguration().setBackgroundImage(defaultBackground);
	}
}
