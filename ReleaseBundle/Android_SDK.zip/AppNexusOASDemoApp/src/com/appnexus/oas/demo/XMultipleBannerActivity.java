package com.appnexus.oas.demo;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;

public class XMultipleBannerActivity extends Activity{
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_multiplebanner);
	}
	
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

}
