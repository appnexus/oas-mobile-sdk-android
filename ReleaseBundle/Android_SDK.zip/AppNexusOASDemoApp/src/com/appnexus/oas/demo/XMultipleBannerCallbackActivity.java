package com.appnexus.oas.demo;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.appnexus.oas.demo.util.Constant;
import com.appnexus.oas.mobilesdk.IAdClickListener;
import com.appnexus.oas.mobilesdk.IReceiveAd;
import com.appnexus.oas.mobilesdk.XAdView;
import com.appnexus.oas.mobilesdk.configuration.XAdSlotConfiguration;
import com.appnexus.oas.mobilesdk.errorhandler.XAdException;

public class XMultipleBannerCallbackActivity extends Activity {
	private TextView txtView1;
	private Handler handler;
	StringBuilder logStr = new StringBuilder();
	
	XAdSlotConfiguration adSlotConfiguration ;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_multiplebannercallback);
		
		handler = new Handler ();
		txtView1 = (TextView)this.findViewById(R.id.txtview1);
		txtView1.setSelected(true);
		txtView1.setMovementMethod(new ScrollingMovementMethod());
		
		showTopBanner();
		showBottomBanner();
		
	}

	private void showTopBanner() {
		XAdView xAdViewtop = new XAdView(this,adListener);
		xAdViewtop.setAdClickListener(adClickListener);
		xAdViewtop.setId(00001);

		xAdViewtop.getAdSlotConfiguration().setScalable(true);
		xAdViewtop.getAdSlotConfiguration().setMaintainAspectRatio(true);
		xAdViewtop.getAdSlotConfiguration().setBannerRefreshInterval(10);
		RelativeLayout.LayoutParams layoutParamsTop = new RelativeLayout.LayoutParams(
				android.view.ViewGroup.LayoutParams.MATCH_PARENT,
				android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
		layoutParamsTop.addRule(RelativeLayout.ALIGN_PARENT_TOP);
		xAdViewtop.setLayoutParams(layoutParamsTop);
		((RelativeLayout)this.findViewById(R.id.multiplebannercallback_id)).addView(xAdViewtop,0);
		xAdViewtop.loadAd(Constant.DEFAULT_DOMAIN_MRAID,"demo_standardbanner", "Bottom", null, null);
	}

	private void showBottomBanner() {
		XAdView xAdViewbottom = new XAdView(this,adListener);
		
		xAdViewbottom.setAdClickListener(adClickListener);
		xAdViewbottom.setId(00002);
		
		xAdViewbottom.getAdSlotConfiguration().setScalable(false);
		xAdViewbottom.getAdSlotConfiguration().setMaintainAspectRatio(true);
		xAdViewbottom.getAdSlotConfiguration().setBannerRefreshInterval(12);
		
		RelativeLayout.LayoutParams layoutParamsBottom = new RelativeLayout.LayoutParams(
				android.view.ViewGroup.LayoutParams.MATCH_PARENT,
				android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
		layoutParamsBottom.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
		xAdViewbottom.setLayoutParams(layoutParamsBottom);
		((RelativeLayout)this.findViewById(R.id.multiplebannercallback_id)).addView(xAdViewbottom,2);
		
		xAdViewbottom.loadAd(Constant.DEFAULT_DOMAIN_MRAID, "www.testmraid.com", "x03", null, null);
	}
	
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}
	
	IAdClickListener adClickListener = new IAdClickListener() {
		
		@Override
		public void onBrowserOpen(XAdView xAdView) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onBrowserClose(XAdView xAdView) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onLeaveApplication(XAdView xAdView) {
			// TODO Auto-generated method stub
			
		}
	};

	

	IReceiveAd adListener = new IReceiveAd() {
		
		@Override
		public void xAdLoaded(final View xAdView) {
			Log.d("XMultipleBannerCallbackActivity", "xAdLoaded()\n"+"The ad was loaded successfully");
			handler.post(new Runnable() {
				public void run() {
					logStr.append(String.format(" \t\txAdLoaded()\n"+"\t\tThe ad was loaded successfully "+xAdView.getId()+"\n"));
					txtView1.setText(logStr);
				}
			});
		}

		@Override
		public boolean xAdShouldDisplay(final View xAdView, WebView adWebView, String htmlContent) {
			Log.d("XMultipleBannerCallbackActivity", "xAdShouldDisplay()\n"+"xAdShouldDisplay method called.");
			handler.post(new Runnable() {
				public void run() {
					logStr.append(String.format(" \t\t xAdShouldDisplay()\n"+"\t\t xAdShouldDisplay method called."+xAdView.getId()+"\n"));
					txtView1.setText(logStr);
				}
			});
			return true;
		}
		
		@Override
		public void xAdFailed(final View xAdView, XAdException xAdError) {
			// TODO Auto-generated method stub
			Log.e("XMultipleBannerCallbackActivity", "Error : "+xAdError.getMessage());
			handler.post(new Runnable() {
				public void run() {
					logStr.append(String.format("\t\txAdFailed()\n"+"\t\tThe ad failed to load"+xAdView.getId()+"\n"));
					txtView1.setText(logStr);
				}
			});
		}
	};
	

}
