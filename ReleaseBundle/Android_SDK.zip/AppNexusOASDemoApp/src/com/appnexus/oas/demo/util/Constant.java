package com.appnexus.oas.demo.util;

public class Constant {
	public static boolean isMraidInterstitial;
	public static boolean isStandardBannerAd;
	
	public static final String DEFAULT_DOMAIN = "oasc-training7.247realmedia.com";
	public static final String DEFAULT_PAGE_NAME = "demo-ads.com";
	public static final String DEFAULT_DOMAIN_MRAID_TF1 = "openad.tf1.fr";
	public static final String PRE_ROLL_VAST_VIDEO_URL = "http://html5demos.com/assets/dizzy.mp4";//"http://www.pocketjourney.com/downloads/pj/video/famous.3gp";

}
