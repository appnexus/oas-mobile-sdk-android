package com.appnexus.oas.demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.appnexus.oas.demo.util.Constant;

public class XMainActivity extends Activity implements OnClickListener {
	
	private Button btnStandardBannerAd;
	private Button btnRichMediaAd;
	private Button btnMultipleBannerAd;
	private Button btnMRAIDInterstitialAd;
	private Button btnVASTInterstitialAd;
	
	private Button btnStandardBannerAdWc;
	private Button btnRichMediaAdWc;
	private Button btnMultipleBannerAdWc;
	private Button btnMRAIDInterstitialAdWc;
	private Button btnVASTInterstitialAdWc;
	private Button btnVastVideoAdWc;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		
		btnStandardBannerAd = (Button)findViewById(R.id.btnstandardbanner);
		btnRichMediaAd = (Button)findViewById(R.id.btnrichmediabanner);
		btnMultipleBannerAd = (Button)findViewById(R.id.btnmultiplebanner);
		btnMRAIDInterstitialAd = (Button)findViewById(R.id.btnmraidinterstitial);
		btnVASTInterstitialAd = (Button)findViewById(R.id.btnvastinterstitial);
		
		btnStandardBannerAdWc = (Button)findViewById(R.id.btnstandardbannerwc);
		btnRichMediaAdWc = (Button)findViewById(R.id.btnrichmediabannerwc);
		btnMultipleBannerAdWc= (Button)findViewById(R.id.btnmultiplebannerwc);
		btnMRAIDInterstitialAdWc = (Button)findViewById(R.id.btnmraidinterstitialwc);
		btnVASTInterstitialAdWc = (Button)findViewById(R.id.btnvastinterstitialwc);
		btnVastVideoAdWc = (Button) findViewById(R.id.btnvastvideowc);
		
		btnStandardBannerAd.setOnClickListener(this);
		btnRichMediaAd.setOnClickListener(this);
		btnMultipleBannerAd.setOnClickListener(this);
		btnMRAIDInterstitialAd.setOnClickListener(this);
		btnVASTInterstitialAd.setOnClickListener(this);
		
		btnStandardBannerAdWc.setOnClickListener(this);
		btnRichMediaAdWc.setOnClickListener(this);
		btnMultipleBannerAdWc.setOnClickListener(this);
		btnMRAIDInterstitialAdWc.setOnClickListener(this);
		btnVASTInterstitialAdWc.setOnClickListener(this);
		btnVastVideoAdWc.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btnstandardbanner:
			Intent intentStandardBannerActivity = new Intent(getApplicationContext(), XStandardBannerActivity.class);
			startActivity(intentStandardBannerActivity);
			break;

		case R.id.btnrichmediabanner:
			Intent intentRichMediaBannerAcivity = new Intent(getApplicationContext(), XRichMediaBannerActivity.class);
			startActivity(intentRichMediaBannerAcivity);
			break;
			
		case R.id.btnmultiplebanner:
			Intent intentMultipleBannerActivity = new Intent(getApplicationContext(), XMultipleBannerActivity.class);
			Constant.isMraidInterstitial = true;
			startActivity(intentMultipleBannerActivity);
			break;
			
		case R.id.btnmraidinterstitial:
			Intent intentInterstitialMraidActivity = new Intent(getApplicationContext(), XInterstitialActivity.class);
			Constant.isMraidInterstitial = true;
			startActivity(intentInterstitialMraidActivity);
			break;
			
		case R.id.btnvastinterstitial:
			Intent intentInterstitialVastActivity = new Intent(getApplicationContext(), XInterstitialActivity.class);
			Constant.isMraidInterstitial = false;
			startActivity(intentInterstitialVastActivity);
			break;
			
		case R.id.btnstandardbannerwc:
			Intent intentStandardbannerwcActivity = new Intent(getApplicationContext(), XBannerWithCallbackActivity.class);
			Constant.isStandardBannerAd = true;
			startActivity(intentStandardbannerwcActivity);
			break;

		case R.id.btnrichmediabannerwc:
			Intent intentRichMediaBannerwcActivity = new Intent(getApplicationContext(), XBannerWithCallbackActivity.class);
			Constant.isStandardBannerAd = false;
			startActivity(intentRichMediaBannerwcActivity);
			break;
			
		case R.id.btnmultiplebannerwc:
			Intent intentMultipleBannerwcActivity = new Intent(getApplicationContext(), XMultipleBannerCallbackActivity.class);
			Constant.isMraidInterstitial = true;
			startActivity(intentMultipleBannerwcActivity);
			break;
			
		case R.id.btnmraidinterstitialwc:
			Intent intentXInterstitialActivity = new Intent(getApplicationContext(), XInterstitialWithCallbackActivity.class);
			Constant.isMraidInterstitial = true;
			startActivity(intentXInterstitialActivity);
			break;
			
		case R.id.btnvastinterstitialwc:
			Intent intentVastInterstitilaActivity = new Intent(getApplicationContext(), XInterstitialWithCallbackActivity.class);
			Constant.isMraidInterstitial = false;
			startActivity(intentVastInterstitilaActivity);
			break;
			
		case R.id.btnvastvideowc:
			Intent intentVastVideoActivity = new Intent(getApplicationContext(), XPrerollVideoActivity.class);
			intentVastVideoActivity.putExtra("isVastInterstitial", false);
			startActivity(intentVastVideoActivity);
			break;
			
		default:
			break;
		}
	}


}
