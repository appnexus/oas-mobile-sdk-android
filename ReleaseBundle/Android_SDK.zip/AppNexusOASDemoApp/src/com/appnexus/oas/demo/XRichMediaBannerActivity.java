package com.appnexus.oas.demo;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.TextView;

import com.appnexus.oas.mobilesdk.IReceiveAd;
import com.appnexus.oas.mobilesdk.errorhandler.XAdException;

public class XRichMediaBannerActivity extends Activity implements IReceiveAd{
	private TextView txtView;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_richmediabanner);
		txtView = (TextView)this.findViewById(R.id.txtview);
	}
	@Override
	public void xAdLoaded(View xAdView) {
		Log.d("XBannerWithCallbackActivity", "xAdLoaded()\n"+"Ad Loaded..");
		txtView.setText( "xAdLoaded()\n"+"Ad Loaded..");
	}
	
	@Override
	public boolean xAdShouldDisplay(View xAdView, WebView adWebView, String htmlContent) {
		Log.d("XBannerWithCallbackActivity", "xAdShouldDisplay()\n"+"xAdShouldDisplay method called.");
		txtView.setText( "xAdShouldDisplay() method called.");	
		return true;
	}
	
	@Override
	public void xAdFailed(View xAdView, XAdException xAdError) {
		Log.e("XBannerWithCallbackActivity", "Error : "+xAdError.getMessage());
		txtView.setText(xAdError.getMessage());
	
	}

}
