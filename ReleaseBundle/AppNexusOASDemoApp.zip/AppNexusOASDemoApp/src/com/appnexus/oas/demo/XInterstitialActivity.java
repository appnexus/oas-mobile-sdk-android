package com.appnexus.oas.demo;

import android.app.Activity;
import android.os.Bundle;

import com.appnexus.oas.demo.util.Constant;
import com.appnexus.oas.mobilesdk.XInterstitialAdDialog;

public class XInterstitialActivity extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_levelsecond);

		// check which standard ad will show.
		if (Constant.isMraidInterstitial == true) {
			showXMraidView();
		} else {

			showVastView();
		}

	}

	// show mraid view
	private void showXMraidView() {
		XInterstitialAdDialog interstitialDialog = new XInterstitialAdDialog(this,Constant.DEFAULT_DOMAIN,
				Constant.DEFAULT_PAGE_NAME, "Frame1", null, null);
		interstitialDialog.getAdSlotConfiguration().setOpenInExternalBrowser(false);
        interstitialDialog.getAdSlotConfiguration().setMediationEnabled(true);
        interstitialDialog.getAdSlotConfiguration().setMediationPlacementId("2054679");
		interstitialDialog.show();
	}

	// show vast view
	private void showVastView() {
		final XInterstitialAdDialog dialog = new XInterstitialAdDialog(
				this, Constant.DEFAULT_DOMAIN, "MSDK-Vast-Renditions", "x25", null, null);
		dialog.getAdSlotConfiguration().setOpenInExternalBrowser(true);
		dialog.show();
	}

}